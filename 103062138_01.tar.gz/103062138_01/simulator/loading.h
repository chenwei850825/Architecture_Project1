#ifndef LOADING_H
#define LOADING_H

#include<iostream>
#include<fstream>
#include<stdlib.h>
#include<string>
#include<bitset>
#include<vector>
#include"declaration.h"
#include"constants.h"
using namespace std;

    class loading {

    public:
        int numberToRead, readCount;
        loading();
        void load();

    };

#endif // LOAD_H
